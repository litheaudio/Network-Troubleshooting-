# Speaker, Router and Access-Point Evidence

Use only customer-authorised logs, an approved Lithe support-log connector, official supported interfaces and the supplied private speaker IP. Do not probe hidden endpoints or expose proprietary details. Read [official-log-connector.md](official-log-connector.md) when a connector is available.

## Acquire evidence

After the five-question intake and live target check, ask one read-only permission checkpoint.

When browser or computer control is available:

1. Open the customer-approved official speaker, router, access-point or mesh interface.
2. Let the customer enter credentials and MFA.
3. Search directly for the supplied speaker IP.
4. Avoid recording unrelated client details.
5. Open only supported event, diagnostics or support-log views.
6. Restrict the time window to 15 minutes before and after the reported fault when possible.
7. Record the current/historical serving AP, band, RSSI, retries, drops, roaming, backhaul and DHCP state when shown.

After Read-mode permission, use `scripts/collect_and_analyze_speaker_logs.py` with the validated private speaker IP. This uses only the Lithe-approved local log source and deletes the raw file after analysis. If direct local access is unavailable, use the same approved URL in the customer-controlled browser and complete the Chrome **Downloads > Keep** checkpoint. Never try spelling variants, enumerate paths or probe another endpoint.

## Run local analysis

Use:

```powershell
python scripts/analyze_speaker_logs.py speaker.log `
  --failure-time "2026-07-29 14:30:00" `
  --timezone "Europe/London" `
  --json
```

The analyser:

- reads local files only;
- scans no device or network;
- emits category counts and timestamps rather than raw lines;
- identifies DHCP, Wi-Fi disconnect, timeout/loss, route/gateway, reboot/watchdog, discovery and roaming/AP-change patterns;
- separates events inside the selected failure window from unrelated history;
- reports the earliest and latest usable log timestamps and whether they cover the supplied failure time;
- returns a smoking-gun-candidate flag only for timestamp-correlated evidence in a log that covers the failure;
- returns a targeted fix, reason and next proof for each category;
- rejects routine successful DHCP messages and generic interface words as fault evidence;
- ranks evidence by causal severity rather than event count alone;
- does not declare a root cause automatically.

## Correlate evidence

| Pattern near the failure | Meaning to test | Corroborate with |
|---|---|---|
| DHCP renew/lease failure, address change or conflict | DHCP churn or duplicate address | Router lease history and reservation |
| Deauthentication, disassociation or reconnect | Radio loss, steering or roaming | Serving AP, RSSI, retries and AP change |
| Timeout, retransmit or packet loss | Connectivity interruption | Ping loss and AP retry/drop counters |
| Gateway unreachable, ARP failure or no route | Local path, VLAN or isolation issue | Gateway, LAN/VLAN and client isolation |
| Reboot, watchdog or uptime reset | Speaker restarted | Uptime, power history and timestamp gap |
| Discovery or multicast failure while IP remains reachable | Local discovery blocked | Guest network, VLAN and multicast controls |
| Roam, BSSID/AP or channel change | AP steering, RF or DFS event | AP history, backhaul, channel and RSSI |

## Confidence standard

Use **Confirmed** only when the event:

- belongs to the affected speaker;
- overlaps the reported failure;
- directly explains lost address, association, reachability, restart or discovery; and
- has corroborating evidence when available.

Use **Likely** when at least two independent observations align. Use **Possible** for one ambiguous event.

Do not call startup messages, old warnings, one timeout outside the failure window or a clean short sample a smoking gun.

Use the highest-ranked time-correlated category to select the smallest targeted fix. Apply nothing until router/AP evidence supports the setting and the customer separately approves Write mode. If evidence categories conflict, present up to three ranked candidates and gather the stated next proof instead of guessing.

When a log is generated after a power cycle, require `failure_time_covered: true` before using it to explain the pre-restart fault. If coverage is false, use the log only as recovery evidence.

Require `future_clock_warning: false`. Normalise timestamps with the supplied IANA timezone. If the speaker clock is ahead, missing or materially inconsistent with router/AP time, report clock alignment as outstanding and do not promote a finding beyond Possible.

## Customer result

Report:

1. measured live loss and latency;
2. whether the official log was downloaded successfully, its size status and whether it covers the failure time;
3. the shortest redacted event summary and serving access-point evidence;
4. **Key issues found:** up to three ranked issues, each labelled Confirmed, Likely or Possible, with evidence and customer impact;
5. the next proof that would confirm or reject each uncertain issue;
6. **What should be fixed and why:** one smallest reversible fix, why it addresses the evidence, the expected benefit and rollback;
7. the exact Write-mode permission checkpoint before any setting is changed.

Never paste complete logs, credentials, public IPs, full MAC addresses, unrelated clients or internal paths into chat or a support report.
