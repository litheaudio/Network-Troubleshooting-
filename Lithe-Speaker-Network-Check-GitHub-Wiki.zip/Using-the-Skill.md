# Using the Skill

## Find the speaker IP

The exact menu labels may vary by app version:

1. Open the Lithe Audio app.
2. Open **Settings**.
3. Select the affected speaker or zone.
4. Open its network or device information.
5. Copy the **IP address**, normally similar to `192.168.1.45`.

## Prepare for testing

1. Connect the computer running Codex to the same home network as the speaker.
2. Disconnect VPN software temporarily.
3. Do not use guest Wi-Fi or mobile data.
4. Leave the speaker powered on for at least two minutes.

## Start the diagnosis

```text
Use $diagnose-lithe-speaker-network to check my speaker at
192.168.1.45 and guide me through fixing it.
```

Replace the example with the IP shown in the app.

## Choose a support mode

### Guide me

Codex explains each action for the customer to complete.

Choose this when the customer is comfortable opening their router or mesh application and following instructions.

### Supervised support

Codex can inspect the customer-opened router page and perform separately approved changes when browser or computer-control tools are available.

Choose this when the customer is unsure or cannot identify the correct router settings. See [Supervised Support](Supervised-Support).

## Questions the skill may ask

The skill asks only questions that help identify the fault, normally one to three at a time:

- How often does the problem happen?
- Does it affect one speaker or several?
- How far is the speaker from the router or access point?
- How many walls or floors are between them?
- Are the walls brick, stone, concrete or foil-backed?
- Is the speaker or access point near metal, a TV, an amplifier or a cabinet?
- Is the home using a router, mesh system, extender or multiple access points?
- Do mesh nodes use wired or wireless backhaul?

## Manual diagnostic command

From the skill directory:

```bash
python scripts/check_speaker_network.py 192.168.1.45 --count 10
```

For an intermittent fault:

```bash
python scripts/check_speaker_network.py 192.168.1.45 --count 20
```

## Verify a repair

After a change:

1. Wait two minutes for reconnection.
2. Confirm the router shows the expected speaker IP.
3. Run a 20-ping test.
4. Play audio for at least five minutes.
5. Confirm the speaker remains visible in the Lithe Audio app.

For a weekly fault, continue monitoring through the next normal DHCP lease cycle.

---

[Home](Home) | [Functions](Functions-and-Diagnostics) | [Supervised Support](Supervised-Support)

