# Troubleshooting

## Codex cannot find the skill

1. Confirm the folder is named `diagnose-lithe-speaker-network`.
2. Confirm `SKILL.md` is directly inside that folder.
3. Confirm the folder is under `.codex/skills`.
4. Restart Codex.
5. Invoke the skill explicitly with `$diagnose-lithe-speaker-network`.

## Python is not found

Install Python 3.10 or newer and ensure `python` is available on the system path.

Check:

```bash
python --version
```

## The IP address is refused

The diagnostic supports only private home-network IPv4 addresses:

- `10.x.x.x`
- `172.16.x.x` through `172.31.x.x`
- `192.168.x.x`

Copy the local IP from the Lithe Audio app while connected to the same home Wi-Fi.

## The speaker is unreachable

Check:

1. Speaker power.
2. The IP currently shown in the Lithe Audio app.
3. The router connected-device list.
4. Whether the IP changed.
5. Guest Wi-Fi or client isolation.
6. VPN software on the diagnostic computer.

## Ping fails but the router shows the speaker online

ICMP may be blocked. Confirm the speaker in the router client list and check whether the safe TCP test responds.

Do not assume the speaker is offline from ping alone.

## The speaker drops out weekly

Check the DHCP reservation first. A periodic problem may coincide with lease renewal or an address change.

Reserve the current speaker IP in the router, reconnect the speaker and monitor through the next normal lease cycle.

## Signal looks good but playback still drops

Review:

- Wi-Fi retry rate;
- AP dropped packets;
- channel congestion;
- AP or mesh-node selection;
- fast roaming;
- latency spikes.

Strong signal does not guarantee a clean radio path.

## Supervised control is unavailable

The Codex environment may not have browser or computer-control tools.

Continue in **Guide me** mode and create a redacted support report if the issue remains.

## The report already exists

The scripts refuse to overwrite existing diagnostics and reports.

Choose a new filename that includes the date or room name.

---

[Home](Home) | [FAQ](Frequently-Asked-Questions) | [Support Reports](Support-Reports)

