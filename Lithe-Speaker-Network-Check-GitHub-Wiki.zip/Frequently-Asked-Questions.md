# Frequently Asked Questions

## Does the skill use a Lithe internal API?

No. It uses normal local-network observations and does not call or disclose an internal or undocumented Lithe API.

## Does it scan the customer's whole network?

No. It checks only the private IP address supplied by the customer.

## Does it upload diagnostic information?

No. Diagnostics and support reports remain local unless the customer chooses to share them.

## Can the customer enter a public IP?

No. Public, loopback, multicast and unsupported addresses are refused.

## Can Codex change router settings?

Only in supervised mode, only when suitable browser or computer-control tools are available, and only after permission for the exact change.

## Who enters the router password?

The customer enters it directly into the router page. The password must never be pasted into chat, dictated, recorded or added to a report.

## Can the customer stop control?

Yes. The customer can say **stop** at any time.

## What happens when browser control is unavailable?

The skill provides guided instructions and can still create a redacted support report.

## Does a healthy test prove the fault is fixed?

No. A short test may not reproduce a weekly or intermittent fault. Continue monitoring through the normal DHCP lease cycle.

## What is the most important fix for a weekly disappearance?

Confirm the speaker's router-side DHCP reservation and verify that no other device uses the same address.

## Should the speaker use a manual static IP?

Prefer a router-side DHCP reservation unless official product documentation specifically requires a manual address.

## What Wi-Fi signal should the speaker have?

Aim for `-67 dBm` or better. Also review retries and packet loss because a strong signal can still be affected by interference.

## Is factory reset the first step?

No. Start with power, current IP, DHCP reservation, signal, retries, AP selection and isolation. Factory reset is a last-resort action.

---

[Home](Home) | [Troubleshooting](Troubleshooting) | [Privacy and Safety](Privacy-and-Safety)

