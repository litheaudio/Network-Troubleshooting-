# Installation

## Requirements

- Codex with support for local skills.
- Python 3.10 or newer.
- A Windows, macOS or Linux computer connected to the same home network as the speaker.
- Optional browser or computer-control capability for supervised router support.

The bundled scripts use the Python standard library and do not require third-party Python packages.

## Install from a release ZIP

Download `diagnose-lithe-speaker-network-v1.1.0.zip`.

### Windows PowerShell

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.codex\skills" | Out-Null
Expand-Archive .\diagnose-lithe-speaker-network-v1.1.0.zip `
  -DestinationPath "$env:USERPROFILE\.codex\skills"
```

### macOS or Linux

```bash
mkdir -p ~/.codex/skills
unzip diagnose-lithe-speaker-network-v1.1.0.zip -d ~/.codex/skills
```

Restart Codex after installation.

## Install directly from GitHub

Use these commands when the repository root contains `SKILL.md`, `agents`, `references` and `scripts`.

### Windows PowerShell

```powershell
git clone https://github.com/YOUR-ORG/YOUR-REPOSITORY.git `
  "$env:USERPROFILE\.codex\skills\diagnose-lithe-speaker-network"
```

### macOS or Linux

```bash
git clone https://github.com/YOUR-ORG/YOUR-REPOSITORY.git \
  ~/.codex/skills/diagnose-lithe-speaker-network
```

Replace the example URL with the real repository URL and restart Codex.

## Confirm the installation

The resulting folder should look like:

```text
~/.codex/skills/
└── diagnose-lithe-speaker-network/
    ├── SKILL.md
    ├── agents/
    ├── references/
    └── scripts/
```

Start a Codex task and enter:

```text
Use $diagnose-lithe-speaker-network to explain how I can check a speaker.
```

If Codex does not find it, see [Troubleshooting](Troubleshooting).

---

[Home](Home) | [Using the Skill](Using-the-Skill)

