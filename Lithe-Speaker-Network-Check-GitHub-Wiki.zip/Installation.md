# Installation

## Install the skill in Codex

The normal installation method is:

1. Open the Lithe Speaker Network Check skill in Codex using the link supplied by Lithe Audio.
2. Select **Install**.
3. Start a new Codex task.

That is all most customers need to do. There are no API keys or Lithe Audio account credentials to enter.

If Lithe Audio shared the skill through a Codex workspace, open **Plugins**, select the **Skills** tab, find the shared skill and select **Install** from its menu.

## Use the skill

Start a new Codex task and enter:

```text
Use $diagnose-lithe-speaker-network to check my Lithe Audio speaker at 192.168.1.45 and guide me through any fixes.
```

Replace `192.168.1.45` with the speaker IP address shown in **Lithe Audio app > Settings**.

Codex will ask permission before running checks or making supervised router changes.

## If you received a skill file

If Lithe Audio sent you a skill file instead of an installation link:

1. Open **Plugins** in Codex.
2. Select the **Skills** tab.
3. Select **Create**, then **Upload from your computer**.
4. Choose the Lithe Audio skill file and complete the installation.

## Requirements

- Codex with Skills enabled.
- A Windows, macOS or Linux computer connected to the same home network as the speaker.
- Permission to run local network checks.
- Router login access only if the customer asks Codex to inspect or change router settings.

If **Install**, **Skills** or **Upload** is unavailable, ask the Codex workspace administrator to enable Skills and skill installation. See [Troubleshooting](Troubleshooting) if the installed skill cannot be found.

---

[Home](Home) | [Using the Skill](Using-the-Skill)
