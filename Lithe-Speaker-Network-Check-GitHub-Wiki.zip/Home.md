# Lithe Speaker Network Check Wiki

Welcome to the documentation for **Lithe Speaker Network Check**, a privacy-focused Codex skill for diagnosing Lithe Audio speaker dropouts, delays, disappearing speakers and home-network connection problems.

The skill helps customers and support teams:

- test one customer-provided private speaker IP address;
- measure reachability, packet loss and latency;
- identify DHCP, Wi-Fi, roaming and local-discovery problems;
- understand the effect of walls, floors, metal, cabinets and access-point placement;
- follow plain-language, step-by-step fixes;
- use supervised router support when suitable browser-control tools are available;
- create a redacted local report for Lithe Audio support.

## Start here

1. [Install the skill](Installation).
2. [Find the speaker IP and run a check](Using-the-Skill).
3. Review the [diagnostic functions](Functions-and-Diagnostics).
4. If the customer is unsure, use [supervised support](Supervised-Support).
5. Create a [redacted support report](Support-Reports) if the problem remains.

## Example request

```text
Use $diagnose-lithe-speaker-network to check my Lithe Audio speaker
at 192.168.1.45 and guide me through fixing any problems.
```

For supervised assistance:

```text
Use $diagnose-lithe-speaker-network to diagnose my speaker at
192.168.1.45. I am unsure how to fix it. Ask about my home Wi-Fi,
offer supervised router support, make only changes I approve, and
create a redacted support report.
```

## Safety summary

The skill checks only the private IP provided by the customer. It does not scan the home network, disclose an internal Lithe API, request router passwords in chat or upload diagnostic data.

The customer remains in control and can say **stop** at any time.

## Documentation

- [Installation](Installation)
- [Using the Skill](Using-the-Skill)
- [Functions and Diagnostics](Functions-and-Diagnostics)
- [Supervised Support](Supervised-Support)
- [Privacy and Safety](Privacy-and-Safety)
- [Support Reports](Support-Reports)
- [Troubleshooting](Troubleshooting)
- [Frequently Asked Questions](Frequently-Asked-Questions)
- [Publishing this Wiki](Publishing-the-Wiki)

