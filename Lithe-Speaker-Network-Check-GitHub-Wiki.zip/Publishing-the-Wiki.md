# Publishing the Wiki

GitHub wikis are separate Git repositories. GitHub allows pages to be edited in the browser or locally through a normal Git workflow.

Official documentation: [Adding or editing wiki pages](https://docs.github.com/en/communities/documenting-your-project-with-wikis/adding-or-editing-wiki-pages).

## 1. Enable and initialise the wiki

1. Open the main GitHub repository.
2. Open the **Wiki** tab.
3. Create the initial **Home** page and save it.

The initial page must exist before cloning the wiki repository.

## 2. Clone the wiki repository

```bash
git clone https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.wiki.git
```

Replace the example owner and repository names.

## 3. Copy these files

Copy all Markdown files from this `wiki` folder into the cloned `.wiki` repository:

```text
Home.md
Installation.md
Using-the-Skill.md
Functions-and-Diagnostics.md
Supervised-Support.md
Privacy-and-Safety.md
Support-Reports.md
Troubleshooting.md
Frequently-Asked-Questions.md
Publishing-the-Wiki.md
_Sidebar.md
_Footer.md
```

Replace the basic `Home.md` created on GitHub with the supplied one.

## 4. Commit and push

```bash
git add .
git commit -m "Add Lithe speaker diagnostic wiki"
git push
```

Only changes pushed to the wiki repository's default branch are published.

## 5. Verify

Open the repository Wiki and confirm:

- the sidebar is visible;
- all internal links open;
- command blocks render correctly;
- the privacy and credential warnings are prominent;
- no placeholder repository URL remains.

Search for and replace:

```text
YOUR-USERNAME
YOUR-ORG
YOUR-REPOSITORY
```

---

[Home](Home) | [Installation](Installation)

