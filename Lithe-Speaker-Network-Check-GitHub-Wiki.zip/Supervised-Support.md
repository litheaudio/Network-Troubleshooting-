# Supervised Support

Supervised support is intended for customers who are unsure how to inspect or change their router.

It requires a Codex environment with suitable browser or computer-control tools.

## Customer control

Before starting, explain that:

- control is limited to the router and affected-speaker diagnosis;
- the customer can watch every action;
- the customer can say **stop** at any time;
- initial inspection is read-only;
- every settings change requires separate confirmation;
- restarts require separate confirmation;
- the customer enters all login details personally.

## Safe login

1. The customer opens the normal local router management page or official router application.
2. Codex pauses if login is required.
3. The customer types the password directly into the router page.
4. The customer completes MFA personally.
5. Codex resumes only after the customer confirms that the router page is open.

The customer must never paste or dictate passwords, MFA codes, recovery codes, tokens or cookies into chat.

## Read-only inspection

After permission, Codex may inspect:

- LAN subnet and DHCP settings;
- the affected speaker client entry;
- current private IP and masked MAC;
- online or offline history;
- band, channel, width and signal;
- retry and drop rates;
- connected access point or mesh node;
- backhaul status;
- client isolation and guest-network placement;
- multicast or local-discovery controls;
- fast-roaming and minimum-RSSI settings.

The workflow does not export the router configuration or record unrelated clients.

## Approving a change

Before every change, Codex explains:

1. the observed evidence;
2. the likely cause;
3. the exact proposed change;
4. which devices may reconnect;
5. how to roll back;
6. how the result will be verified.

Codex then asks:

> Would you like me to make this exact change now?

Approval for one change is not approval for another.

## Prohibited actions

The supervised workflow does not:

- enable remote router administration;
- add port forwarding;
- disable the firewall;
- expose the speaker to the internet;
- perform an early factory reset;
- change WAN or ISP settings;
- inspect password managers or saved browser passwords;
- control unrelated applications, files, accounts or devices.

Firmware updates and broad network redesign require a separate maintenance decision outside the normal workflow.

## Verification

After an approved change:

1. Confirm that the speaker reconnects.
2. Check the expected IP and access point.
3. Run a 20-ping sample.
4. Compare signal, loss, latency and retries.
5. Ask the customer to play audio.
6. Record the outcome in the support log.

If browser control is unavailable, Codex must fall back to guided instructions and must not claim it inspected or changed the router.

---

[Home](Home) | [Privacy and Safety](Privacy-and-Safety) | [Support Reports](Support-Reports)

