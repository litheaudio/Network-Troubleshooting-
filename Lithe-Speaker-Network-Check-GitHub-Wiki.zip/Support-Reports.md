# Support Reports

The skill can create a local, redacted Markdown report for Lithe Audio support.

The report is not uploaded or sent automatically. The customer reviews it before sharing.

## Create the diagnostic file

```bash
python scripts/check_speaker_network.py 192.168.1.45 \
  --count 20 \
  --save-json diagnostic.json
```

The script refuses to overwrite an existing diagnostic file.

## Create the support report

```bash
python scripts/create_support_report.py \
  --diagnostic-json diagnostic.json \
  --output Lithe-Support-Report.md \
  --field "symptom=Speaker drops out weekly" \
  --field "frequency=About once a week" \
  --field "walls=Two brick walls" \
  --field "barriers=TV and metal equipment cabinet" \
  --field "router_model=Customer-provided router model" \
  --field "changes=Created a DHCP reservation" \
  --field "verification=20/20 replies and playback test passed"
```

## Supported fields

```text
symptom
frequency
first_seen
router_model
network_type
access_point
band
signal_dbm
retries_percent
dhcp_reserved
distance_m
walls
floors
barriers
speaker_location
other_devices
changes
verification
customer_notes
```

## What the report includes

- Affected private speaker IP.
- Masked MAC, when available.
- Diagnostic timestamp.
- Packet loss and latency measurements.
- Symptoms and frequency.
- Relevant physical barriers.
- Router and AP evidence.
- Changes made.
- Before-and-after results.
- Verification outcome.

## What the report excludes

- Router or Wi-Fi passwords.
- MFA and recovery codes.
- Tokens, cookies and API keys.
- Public IP addresses.
- Unrelated client details.
- Router configuration exports.
- Login-page screenshots.

## Before sending

The customer should open the Markdown report and confirm:

1. the description is accurate;
2. no private login information is present;
3. only the affected speaker is documented;
4. the actions and results are complete.

---

[Home](Home) | [Privacy and Safety](Privacy-and-Safety) | [Troubleshooting](Troubleshooting)

