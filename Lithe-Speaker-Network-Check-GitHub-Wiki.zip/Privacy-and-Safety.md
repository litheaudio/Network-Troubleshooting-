# Privacy and Safety

## What the skill is allowed to do

- Validate one customer-provided private IPv4 address.
- Send a limited ping sample to that address.
- Look up the neighbour entry for that address only.
- Attempt TCP connections to ports 80 and 443 without sending an HTTP request.
- Report reachability, packet loss, latency and a masked MAC.
- Inspect a customer-opened router page after permission.
- Perform one explained router change after permission for that exact change.
- Save a redacted local report when requested.

## What the skill must not do

- Probe a public IP address.
- Sweep a subnet or enumerate unrelated devices.
- Call or disclose an internal, private or undocumented Lithe API.
- Extract firmware, tokens, keys, cookies or router backups.
- Ask the customer to reveal a router or Lithe account password.
- Upload diagnostic data automatically.
- Store a report unless the customer requests it.
- Enable remote administration, port forwarding or WAN exposure.
- Disable the firewall.
- Control unrelated applications, files, accounts or devices.

## Credential handling

The customer types router credentials directly into the normal router page and completes MFA personally.

Codex must not:

- request credentials in chat;
- read them aloud;
- copy or store them;
- include them in screenshots;
- add them to a support report;
- inspect a password manager or saved-password page.

## Redaction

Support reports:

- mask full MAC addresses;
- remove likely passwords, tokens and recovery codes;
- redact public IP addresses;
- omit usernames and email addresses;
- omit unrelated network clients;
- omit router configuration exports.

## Consent checkpoints

Obtain separate permission:

1. before saving a support log;
2. before inspecting an authenticated router session;
3. before every settings change;
4. before restarting a router, AP or speaker.

Stop immediately if the customer says **stop**.

---

[Home](Home) | [Supervised Support](Supervised-Support) | [Support Reports](Support-Reports)

