# Functions and Diagnostics

## Diagnostic functions

| Function | Purpose |
|---|---|
| Private-IP validation | Refuses public, loopback, multicast and unsupported addresses |
| Targeted ping | Measures reachability, packet loss and latency |
| Local source selection | Helps identify VPN or incorrect-network routing |
| Target-only neighbour lookup | Confirms local presence while masking the MAC |
| Safe TCP connection test | Checks ports 80 and 443 without sending an HTTP request |
| DHCP review | Finds changed addresses, lease problems and address conflicts |
| Signal review | Identifies weak Wi-Fi coverage |
| Retry and drop review | Identifies interference or access-point congestion |
| Band and channel review | Identifies unstable 2.4 GHz or 5 GHz conditions |
| AP and mesh review | Identifies poor roaming or an unsuitable AP lock |
| Isolation review | Identifies guest-network or client-isolation problems |
| Physical-environment intake | Considers walls, floors, metal, cabinets and placement |
| Redacted reporting | Produces a local support-ready Markdown report |

## Result categories

### Healthy

The speaker is reachable with no measured loss and stable local latency.

A healthy short test does not completely rule out an intermittent problem. Check DHCP history and Wi-Fi events when the fault happens weekly.

### Degraded

The test found one or more of:

- packet loss above 0%;
- average local latency above 50 ms;
- latency spikes above 100 ms.

Check signal, retries, channel congestion, AP health and roaming.

### ICMP blocked

Ping did not respond but a safe TCP connection succeeded. The speaker may still be online. Confirm it in the router client list.

### Unreachable

Neither ping nor the safe TCP checks responded.

Check power, the IP shown in the app, the router client list, guest isolation and DHCP changes.

### Route warning

The computer selected an unexpected network route. Disconnect VPN software and reconnect to the same home network as the speaker.

## Practical targets

- Packet loss: `0%`
- Average local latency: preferably below `20 ms`
- Large latency spikes: none above `100 ms`
- Signal: preferably `-67 dBm` or better
- Retry rate: preferably below `10%`
- DHCP reservation: enabled for the speaker

## Common repairs

- Create a router-side DHCP reservation.
- Correct a changed or conflicting speaker IP.
- Improve access-point placement.
- Use 20 MHz width on 2.4 GHz.
- Select channel 1, 6 or 11 according to local congestion.
- Avoid weak 5 GHz coverage through dense walls.
- Remove an unsuitable AP lock.
- Disable fast roaming for a stationary speaker or IoT SSID.
- Correct guest or client-isolation settings.
- Review multicast and local-discovery controls.

---

[Home](Home) | [Using the Skill](Using-the-Skill) | [Troubleshooting](Troubleshooting)

